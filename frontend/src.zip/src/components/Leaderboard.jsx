import React from "react";

function Leaderboard() {
  return (
    <>
      <div className="main">hello</div>
    </>
  );
}

export default Leaderboard;
