import React from "react";
import Hero from "../components/Hero";

function Index() {
  return (
    <>
      <Hero />
    </>
  );
}

export default Index;
