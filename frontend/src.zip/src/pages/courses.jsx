import React from "react";
import Leaderboard from "../components/Leaderboard";

function Courses() {
  return (
    <>
      <Leaderboard />
    </>
  );
}

export default Courses;
